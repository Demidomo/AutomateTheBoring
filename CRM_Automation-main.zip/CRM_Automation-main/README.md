Automation with Phoenix CRM 

- Documenting ACW notes 
- Look up PHoneix account info 


Plug-in used: 
- Chromium Automation
- iMacro
